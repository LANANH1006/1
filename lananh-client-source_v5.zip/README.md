# LAN ANH CLIENT PVP BETA (Fabric 1.21.4)

Mod client-side: Elytra Mace, Auto Crystal/Pearl, Safe Anchor, ESP + dây, ESP Block, Radar, Printer schematic.

## Build bằng GitHub (không cần cài gì)
1. Tạo repo GitHub, upload toàn bộ thư mục này.
2. Tab **Actions** -> workflow **Build** chạy tự động -> tải artifact `LanAnhClient-jar`.
3. Bỏ file `.jar` vào `.minecraft/mods` cùng **Fabric Loader 0.16+** và **Fabric API 0.119.2+1.21.4**.

## Phím mặc định (đổi trong Controls)
RShift = menu • R = Elytra Mace • G = Safe Anchor • P = Printer

## Schematic
Đặt file `.litematic` vào `.minecraft/schematics/`, vào menu -> *Xây theo Schematic* -> chọn file -> đứng vào gốc muốn xây -> bật Printer.

## Hình nền (Hello Kitty hoặc ảnh bất kỳ của bạn)
Đặt ảnh PNG 512x512 tại `src/main/resources/assets/safeanchor/textures/gui/bg.png`. Không có ảnh thì dùng nền hồng.


## v2.3 (mới)
- Block ESP: chỉnh độ đậm màu; quét nhẹ hơn (giảm lag), khung schematic cache
- Mace liên tục (Menu > Elytra Mace), Auto PvP (V), Tự đào kiểu Baritone (N)
- Printer: xây theo hàng (tự chuyển hàng), chỉ đặt theo hướng nhìn, tự đi tới chỗ xây
- Auto /ah mua, Sus chunk (đỏ), Dịch chat Anh <-> Việt

## v2.4
- Menu: animation chữ CLIENTS BY LAN ANH, chia hàng module (ESP / PvP / Xây / Hiển thị / Khác), vuốt ngang để đổi hàng
- Shockwave, Trail, Chroma, đổi giờ bầu trời, Velocity, Combo Anchor 1 phím (J), HUD FPS/Ping/RAM/Keystrokes

## v2.5 (học từ PURXIY)
Jump Circle, Ripple, Block Outline trượt, Place Animation, Triggerbot, Hit Select, Silent Aura, Configs, HUD CPS/thuốc/giáp/combo/module list

## v2.6
Hit Splash, Target ESP, Radiance, Afterglow, lưới Cyberspace, Shockwave ô sáng, Bridge, Name Tags, vòng tâm ngắm, đếm Totem

## v2.7
- Bảng màu mới (mọi chỗ chọn màu): chuột phải kéo / click vào lưới màu hoặc hàng màu nhạt
- Ô nhập item/block có hình 2D: gõ "log" -> hiện toàn bộ, vuốt lên/xuống, chạm để thêm (ESP Block, Tự đào, Auto /ah)
- Chặn mở rương / hopper / shulker / thùng... (ngồi shift để mở) • Macro Crystal • Tâm tự vẽ • Bầu trời ảo (màu tùy chỉnh)
- Trail: dưới chân / giữa người / trên đầu • Shockwave khối nhô lên rồi rớt xuống từ từ
- Safe Anchor: 1 click, đúng 1 obsidian chắn rồi nổ • Elytra Mace: chuỗi đập (bị hất lên nhẹ -> dùng cánh lao xuống đập tiếp) • bỏ Mace liên tục
- Workflow build: repo có thể để source ở thư mục gốc hoặc bằng file lananh-client-source.zip

## v2.8
- Spin Bot: nhân vật xoay (người khác thấy), camera đứng yên, chỉnh tốc độ/hướng

## v2.9
- Bỏ Spin Bot
- Radar: tự quét xuyên tường (không cần nhìn thấy), block hiện icon 2D, ▲ trên / ▼ dưới kèm chênh cao
- Mace: thả rơi thẳng theo đà (không lao chéo nên hết bị bật qua đầu), đập ngay khi rơi (smash không cần cooldown đầy)
- "Chân ngang đầu": cầm mace, đang rơi, chân hạ tới ngang đầu đối thủ là đánh luôn
- Macro tự thiết kế (phím K): xếp bước anchor / glowstone / obsidian / crystal / totem / chờ... theo ý muốn
- Trượt mượt khi tp (pearl, chorus...): camera lướt từ chỗ cũ tới chỗ mới
- Âm bàn phím kiểu Creamy Keys
