package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

/** Tự đặt obsidian 4 hướng quanh chân (CPvP). */
public class Surround {
    static int cd;
    static final Direction[] DIRS = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (!c.surround || !c.enabled || p == null || mc.world == null) return;
        if (cd > 0) { cd--; return; }
        if (!p.isOnGround() || !Util.has(s -> s.isOf(Items.OBSIDIAN))) return;
        BlockPos f = p.getBlockPos();
        for (Direction d : DIRS) {
            BlockPos q = f.offset(d);
            if (mc.world.getBlockState(q).isReplaceable() && mc.world.getOtherEntities(null, new Box(q)).isEmpty()) {
                if (Util.placeBlock(q, Items.OBSIDIAN)) { cd = 1; return; }
            }
        }
    }
}
